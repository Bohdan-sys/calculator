export const buttons = [
    {
        name: 'AC',
        action: 'clear'
    },
    {
        name: '/',
        action: 'divide'
    },
    {
        name: 'X',
        action: 'multiply'
    },
    {
        name: '7',
        action: 'seven'
    },
    {
        name: '8',
        action: 'eight'
    },
    {
        name: '9',
        action: 'nine'
    },
    {
        name: '-',
        action: 'subtract'
    },
    {
        name: '4',
        action: 'four'
    },
    {
        name: '5',
        action: 'five'
    },
    {
        name: '6',
        action: 'six'
    },
    {
        name: '+',
        action: 'add'
    },
    {
        name: '1',
        action: 'one'
    },
    {
        name: '2',
        action: 'two'
    },
    {
        name: '3',
        action: 'three'
    },
    {
        name: '=',
        action: 'equals'
    },
    {
        name: '0',
        action: 'zero'
    },
    {
        name: '.',
        action: 'decimal'
    }
]